# tf_cka
Centered Kernel Alignment (CKA) implementation with tensorflow 2.0
